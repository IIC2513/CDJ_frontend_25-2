import { useMemo, useState } from "react";
import "./MiPagina.css";
import StatCard from "../../components/StatCard/StatCard";
import Tag from "../../components/Tag/Tag";
import ProgressBar from "../../components/ProgressBar/ProgressBar";
import AlertsList from "../../components/AlertsList/AlertsList";
import TodoList from "../../components/TodoList/TodoList";
import PomodoroTimer from "../../components/PomodoroTimer/PomodoroTimer";

export default function MiPagina() {
  const [subs] = useState(["Cálculo III", "EDO", "Química", "Álgebra Lineal"]);
  const [likes] = useState(16);
  const [uploads] = useState(3);
  const [pomos] = useState(5);

  const [todos, setTodos] = useState([
    { id: 1, text: "Tarea de Cálculo III.", done: true },
    { id: 2, text: "Rehacer ayudantía EDO.", done: false },
    { id: 3, text: "Publicar borrador.", done: false },
    { id: 4, text: "Estudiar derivadas.", done: false },
  ]);
  const toggleTodo = (id) =>
    setTodos(xs => xs.map(it => it.id === id ? { ...it, done: !it.done } : it));

  const progreso = useMemo(() => {
    const total = todos.length || 1;
    const done  = todos.filter(t => t.done).length;
    return Math.round((done / total) * 100);
  }, [todos]);

  const [alerts] = useState([
    { user: "Micaela Henríquez", text: "acaba de publicar un archivo sobre QUÍMICA:", meta: "“Ácido y base”." },
    { user: "Javier M.",        text: "acaba de publicar sobre EDO:",            meta: "“¿Qué es la linealidad?”." },
  ]);

  return (
    <div className="page mp">
      <h1 className="h1-explora">Mi página 📊</h1>

      <div className="mp-grid">

        {/* ========= COLUMNA 1 ========= */}
        <section className="col1">

            {/* 3 stats en la misma fila */}
            <div className="stats-row">
            <StatCard value={likes}   label="LIKES RECIBIDOS" />
            <StatCard value={pomos}   label="POMODOROS COMPLETADOS" />
            <StatCard value={uploads} label="ARCHIVOS SUBIDOS" />
            </div>

            {/* Abajo: Suscripciones + Pomodoro */}
            <div className="col1-bottom">
            <div className="mp-card subs">
                <div className="mp-card-title">SUSCRIPCIONES</div>
                <div className="tags">
                {subs.map((t, i) => <Tag key={t} text={t} active={i===3} />)}
                </div>
            </div>

            <PomodoroTimer workMinutes={25} />  {/* su CSS define .pomo-card */}
            </div>
        </section>

        {/* ========= COLUMNA 2 ========= */}
        <section className="col2">
            <ProgressBar value={progreso} />      {/* muestra % dinámico */}
            <AlertsList items={alerts} />
        </section>

        {/* ========= COLUMNA 3 ========= */}
        <section className="col3">
            <TodoList items={todos} onToggle={toggleTodo} />
        </section>

        </div>

    </div>
  );
}